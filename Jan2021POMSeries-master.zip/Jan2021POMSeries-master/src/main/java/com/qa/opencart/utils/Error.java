package com.qa.opencart.utils;

public class Error {
	
	public static final String ACC_PAGE_TITLE_ERROR = "Accounts Page Title is not correct";
	public static final String ACC_PAGE_HEADER_ERROR = "Accounts Page Header is not correct";
	public static final String LOGOUT_LINK_NOT_PRESENT = "LOGOUT LINK IS MISSING";

}
