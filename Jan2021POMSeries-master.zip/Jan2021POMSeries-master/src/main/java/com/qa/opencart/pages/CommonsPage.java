package com.qa.opencart.pages;

public class CommonsPage {
	
	//search
	//addtocart
	

}
