package SeleniumArch;

public interface SearchContext {
	
	public void findElement();
	
	
	

}
