package JavaSessions;

public class Window {
	
	@Override
	public void finalize() {
		System.out.println("Window -- finalize");
	}
	
	
	

}
