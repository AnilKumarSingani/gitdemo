package JavaSessions;

public class FinalKeyword {

	public static void main(String[] args) {

		final int i = 10;
		System.out.println(i);
		
		final int days = 7;
		System.out.println(days * 10);
		
	}

}
