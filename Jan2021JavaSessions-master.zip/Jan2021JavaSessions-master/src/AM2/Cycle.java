package AM2;

import AccessModifiers.Car;

public class Cycle {

	public static void main(String[] args) {

		Car c = new Car();
		c.price = 300;
		
		
		
	}

}
