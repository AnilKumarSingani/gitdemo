package WebDriverArch;

public class User {

	public static void main(String[] args) {

		Browser br = new Browser();
		br.launchBrowser();
		
		
	}

}
