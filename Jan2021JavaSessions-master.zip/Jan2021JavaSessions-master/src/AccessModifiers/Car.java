package AccessModifiers;

public class Car {
	
	String name;
	private String engine;
	public int price;
	protected String color;
	
	public static void main(String a[]) {
		
		Car c = new Car();
		c.name = "BMW";
		
		
		
	}
	
	

}
