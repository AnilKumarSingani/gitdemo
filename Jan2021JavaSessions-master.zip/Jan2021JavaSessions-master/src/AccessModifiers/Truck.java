package AccessModifiers;

public class Truck {
	
	public static void main(String[] args) {

		Car c = new Car();
		
		
		
	}


}
