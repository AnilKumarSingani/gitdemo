package OOP_Interface;

public class Medical {
	
	public void RD(){
		System.out.println("medical -- RD");
	}
	
	

}
