package OOP_Interface;

public interface IndianMedical extends WHO{

	public void cardioServices();

	public void oncologyServices();

	public void emergencyServices();

}
