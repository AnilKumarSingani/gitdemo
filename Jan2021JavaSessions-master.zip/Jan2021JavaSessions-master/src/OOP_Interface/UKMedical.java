package OOP_Interface;

public interface UKMedical extends WHO{

	public void physioServices();

	public void gynecServices();
	
	public void emergencyServices();


}
