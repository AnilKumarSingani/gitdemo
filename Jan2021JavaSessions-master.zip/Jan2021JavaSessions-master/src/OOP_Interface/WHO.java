package OOP_Interface;

public interface WHO {
	
	public void covidTest();
	

}
