package OOP_Inheritance;

public class Audi extends Car{
	
	
	public void theftSafety() {
		System.out.println("Audi -- theftsafety");
	}
	
	
	
	

}
