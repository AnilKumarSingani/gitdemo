package OOP_Inheritance;

public class Car extends Vehicle{
	
	String name = "My Car";

	public void start() {
		System.out.println("Car -- start");
	}

	public void stop() {
		System.out.println("Car -- stop");
	}

	public void refuel() {
		System.out.println("Car -- refuel");
	}
	
	public static void autoPilot() {
		System.out.println("Car -- autoPilot");
	}
	
	
	//Univ -- parent -- 3/4 methods
	//3 child classes -- college classes -- 2/3 methods 
	//CentralUnvi -- Grant Parent
	//test college class --> 
	
	
	
	

}
