package OOP_Inheritance;

public class Truck {
	
	public void heavyLoading() {
		System.out.println("truck -- heacy loading");
	}
	

}
